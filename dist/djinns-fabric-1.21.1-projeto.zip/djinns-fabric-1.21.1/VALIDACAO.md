# Validação — estado real

## Resultados neste ambiente

- Gradle 8.8 oficial: SHA-256 conferido.
- Nove arquivos Java analisados pelo parser Java 21, sem erros de sintaxe.
  Isso **não** verifica resolução de tipos e métodos.
- Imports e assinaturas revisados com os mapeamentos oficiais Yarn 1.21.1 e
  o código oficial Fabric API da linha 1.21.1.
- Recursos: execute `python3 tools/validate_resources.py` para conferir JSON,
  PNG, referências a texturas/modelos, traduções, receitas e loot.
- A validação estática passou: 69 JSON, 33 PNG com CRC/zlib íntegros, 17 entidades,
  12 itens de equipamento/pergaminhos, 7 receitas e traduções PT-BR/inglês.
- JDK Temurin 21.0.9+10 completo instalado a partir do GitHub oficial Adoptium,
  com SHA-256 conferido, em `/workspace/tools/jdk-21.0.9+10`.
- **Build não concluído:** `maven.fabricmc.net` recebeu HTTP 403 do proxy.
  O Gradle encerrou na resolução de `fabric-loom:1.7.4`, antes de compilar Java.
- **Não executados:** compilação com classpath Minecraft/Fabric, geração de
  JAR remapeado, inicialização do cliente/servidor e verificações em jogo.
- Nenhum teste funcional no Minecraft foi aprovado ainda.

## Retomar a compilação na nuvem

Os domínios necessários foram salvos no rascunho do ambiente:
`maven.fabricmc.net`, `maven.mojang.com`, `libraries.minecraft.net`,
`piston-meta.mojang.com`, `piston-data.mojang.com`,
`resources.download.minecraft.net`, `meta.fabricmc.net`.
Revise e salve nas configurações do ambiente; publique quando solicitado pela
plataforma. Salvar o rascunho sozinho não aplica a rede à máquina em execução.

Com a rede aplicada e um JDK 21 completo, execute `./gradlew build` e resolva
quaisquer falhas de compilação/runtime reveladas. O ZIP atual é código-fonte.
Na máquina de nuvem preparada, `python3 tools/build_cloud.py` seleciona o JDK e
o Gradle instalados e usa as configurações herdadas de proxy sem expor segredos.

## Aceite manual pendente

1. `./gradlew build`: sucesso e JAR remapeado em `build/libs`.
2. `./gradlew runClient`: abrir mundo e aba criativa; conferir todos os mobs e
   itens, sem texturas/modelos ausentes. Conferir a aparência em primeira e
   terceira pessoa, inclusive armadura e escudo usando/bloqueando.
3. `/function djinns:showcase`: confirmar 16 variantes, cauda animada, flutuação
   e neutralidade. Verificar aparecimento natural num deserto.
4. Em Sobrevivência, ferir um djinn: aliados até 32 blocos reagem. Sem novo dano,
   a agressividade cessa em 30 s. Criativo/Espectador não devem ser perseguidos.
5. Confirmar bolas de fogo vermelhas com colisão e dano, Levitação branca,
   Lentidão/Escuridão negra e magias com linha de visão.
6. `/effect give @s djinns:possession 5` em Sobrevivência: confirmar movimento
   involuntário e ataques do jogador contra criaturas visíveis próximas. Após
   100 ticks, o controle retorna. Esse comando isolado não aplica Cegueira e
   Náusea; elas acompanham o gatilho de ataque real.
7. Testar o gatilho real com golpes corpo a corpo que causem dano e intervalos
   suficientes. Os 15% são probabilísticos: uma tentativa sem proc não é falha.
   Projéteis não devem causar possessão. Não aceitar somente o teste com
   `/effect` como prova de funcionamento do gatilho.
8. Trocar lápis com comuns, comerciantes e magos: confirmar consumo, item
   entregue, estoque, XP, evolução até nível 5 e reposição após virar o dia.
   Testar as 13 bancadas antes da primeira troca; depois dela, profissão fixa.
9. `/function djinns:kit`: testar todos os pergaminhos, consumo, cooldown,
   espada flamejante, lança, durabilidade e proteção da armadura.
10. Invocar o rei em área aberta e atacá-lo em Sobrevivência: conferir barra,
    animação, arco de espada, fendas, tempo de preparação e guardas invocados.
    Na segunda fase, fendas mais frequentes. Limite de seis próximos, expiração
    em 60 s e sem loot/XP dos invocados. Confirmar drop da espada ao derrotar o rei.
11. Salvar e reabrir o mundo; conferir persistência de equipamento, profissão,
    ofertas, nível, hostilidade restante e prazo dos invocados.
12. Repetir num servidor dedicado Fabric com dois clientes: nenhum crash de
    classes client-only, sincronização dos efeitos e nenhuma possessão forçando PvP.

Todo o roteiro de jogo acima está **pendente**.

package dev.minesla.djinn.client;

import dev.minesla.djinn.DjinnEntity;
import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;

public final class DjinnModel extends SinglePartEntityModel<DjinnEntity> implements ModelWithArms, ModelWithHead {
    private final ModelPart root, spirit, head, leftArm, rightArm, tail, tail2, tail3, guardArmor, royalArmor, sash, turban;
    public DjinnModel(ModelPart root) {
        this.root = root; spirit = root.getChild("spirit"); head = spirit.getChild("head");
        leftArm = spirit.getChild("left_arm"); rightArm = spirit.getChild("right_arm");
        tail = spirit.getChild("tail"); tail2 = tail.getChild("tail2"); tail3 = tail2.getChild("tail3");
        guardArmor = spirit.getChild("guard_armor"); royalArmor = spirit.getChild("royal_armor");
        sash = spirit.getChild("sash"); turban = head.getChild("turban");
    }
    public static TexturedModelData createModel() {
        ModelData data = new ModelData();
        ModelPartData spirit = data.getRoot().addChild("spirit", ModelPartBuilder.create(), ModelTransform.pivot(0, 24, 0));
        spirit.addChild("torso", ModelPartBuilder.create().uv(0, 0).cuboid(-5, -24, -3, 10, 12, 6)
                .uv(64, 32).cuboid(-5.5f, -25, -3.5f, 11, 2, 7), ModelTransform.NONE);
        ModelPartData head = spirit.addChild("head", ModelPartBuilder.create().uv(0, 32).cuboid(-4, -6, -4, 8, 8, 8)
                .uv(0, 96).cuboid(-2.8f, -3, -4.12f, 1.6f, 1.3f, .2f)
                .uv(0, 96).cuboid(1.2f, -3, -4.12f, 1.6f, 1.3f, .2f)
                .uv(64, 32).cuboid(-4.6f, -1.5f, -.5f, 1, 3, 1)
                .uv(64, 32).cuboid(3.6f, -1.5f, -.5f, 1, 3, 1), ModelTransform.pivot(0, -27, 0));
        head.addChild("turban", ModelPartBuilder.create().uv(32, 32).cuboid(-5, -9, -5, 10, 4, 10)
                .uv(32, 32).cuboid(-4.5f, -10.5f, -4.5f, 9, 2, 9)
                .uv(64, 32).cuboid(-1.5f, -10, -5.4f, 3, 5, 1)
                .uv(32, 96).cuboid(-.8f, -9.4f, -5.7f, 1.6f, 3, .5f)
                .uv(32, 32).cuboid(2, -5, 3.5f, 3, 11, 1), ModelTransform.NONE);
        spirit.addChild("left_arm", ModelPartBuilder.create().uv(0, 0).cuboid(0, -1, -2, 4, 12, 4)
                .uv(64, 32).cuboid(-.3f, 6, -2.3f, 4.6f, 2.5f, 4.6f), ModelTransform.pivot(5, -23, 0));
        spirit.addChild("right_arm", ModelPartBuilder.create().uv(0, 0).cuboid(-4, -1, -2, 4, 12, 4)
                .uv(64, 32).cuboid(-4.3f, 6, -2.3f, 4.6f, 2.5f, 4.6f), ModelTransform.pivot(-5, -23, 0));
        spirit.addChild("sash", ModelPartBuilder.create().uv(64, 64).cuboid(-5.3f, -14, -3.3f, 10.6f, 5, 6.6f)
                .uv(64, 32).cuboid(-5.6f, -15, -3.6f, 11.2f, 2, 7.2f)
                .uv(32, 96).cuboid(-1, -15, -4, 2, 3, .8f)
                .uv(64, 64).cuboid(3.2f, -10, -3.5f, 2.4f, 6, 1), ModelTransform.NONE);
        ModelPartData tail = spirit.addChild("tail", ModelPartBuilder.create().uv(64, 0).cuboid(-3.5f, 0, -2.5f, 7, 4, 5), ModelTransform.pivot(0, -10, 0));
        ModelPartData tail2 = tail.addChild("tail2", ModelPartBuilder.create().uv(64, 0).cuboid(-2.5f, 0, -2, 5, 4, 4), ModelTransform.pivot(.5f, 3, 0));
        tail2.addChild("tail3", ModelPartBuilder.create().uv(64, 0).cuboid(-1.5f, 0, -1.5f, 3, 5, 3)
                .uv(64, 0).cuboid(-.5f, 5, -.5f, 1, 2, 1), ModelTransform.pivot(0, 3, 0));
        spirit.addChild("guard_armor", ModelPartBuilder.create().uv(64, 32).cuboid(-7, -25, -4, 5, 3, 8)
                .uv(64, 32).cuboid(2, -25, -4, 5, 3, 8)
                .uv(96, 32).cuboid(-5.4f, -22, -3.5f, 10.8f, 6, 1), ModelTransform.NONE);
        spirit.addChild("royal_armor", ModelPartBuilder.create().uv(64, 32).cuboid(-8, -26, -4.5f, 6, 2, 9)
                .uv(64, 32).cuboid(2, -26, -4.5f, 6, 2, 9)
                .uv(32, 32).cuboid(-5, -13, 3, 10, 12, 1)
                .uv(32, 96).cuboid(-1, -22, -3.8f, 2, 6, 1), ModelTransform.NONE);
        return TexturedModelData.of(data, 128, 128);
    }
    @Override public ModelPart getPart() { return root; }
    @Override public ModelPart getHead() { return head; }
    @Override public void setArmAngle(Arm arm, MatrixStack matrices) {
        spirit.rotate(matrices);
        (arm == Arm.LEFT ? leftArm : rightArm).rotate(matrices);
    }
    @Override public void setAngles(DjinnEntity entity, float limbAngle, float limbDistance, float age, float yaw, float pitch) {
        root.traverse().forEach(ModelPart::resetTransform);
        spirit.pivotY += MathHelper.sin(age * .08f) * 1.1f;
        head.yaw = yaw * MathHelper.RADIANS_PER_DEGREE;
        head.pitch = pitch * MathHelper.RADIANS_PER_DEGREE * .6f;
        rightArm.roll = -.12f - MathHelper.sin(age * .07f) * .05f;
        leftArm.roll = .12f + MathHelper.sin(age * .07f) * .05f;
        rightArm.pitch = -.12f + MathHelper.sin(age * .06f) * .08f;
        leftArm.pitch = -.12f - MathHelper.sin(age * .06f) * .08f;
        tail.roll = MathHelper.sin(age * .10f) * .2f;
        tail2.roll = MathHelper.sin(age * .10f - .7f) * .28f;
        tail3.roll = MathHelper.sin(age * .10f - 1.4f) * .35f;
        tail.yaw = age * .025f;
        tail.pivotY -= 3;
        guardArmor.visible = entity.role() == 2;
        royalArmor.visible = entity.isKing();
        turban.visible = true;
        if (entity.role() == 1) leftArm.pitch = -.65f;
        if (entity.role() == 2) leftArm.pitch = -.9f;
        if (entity.castingTicks() > 0) {
            rightArm.pitch = -1.8f; leftArm.pitch = -1.8f;
            rightArm.roll = -.5f; leftArm.roll = .5f;
        }
        // Cubic easing winds the sword up, sweeps it, then smoothly returns to idle.
        float swing = handSwingProgress;
        if (swing > 0) {
            float eased = 1 - (float)Math.pow(1 - swing, 3);
            float sweep = MathHelper.sin(eased * MathHelper.PI);
            rightArm.pitch -= sweep * 2.3f;
            rightArm.yaw = -.8f * sweep;
            spirit.yaw += MathHelper.sin(swing * MathHelper.PI) * .5f;
            head.yaw -= spirit.yaw;
        }
    }
}

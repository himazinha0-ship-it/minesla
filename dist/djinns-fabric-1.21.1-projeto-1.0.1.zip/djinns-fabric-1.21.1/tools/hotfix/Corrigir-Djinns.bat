@echo off
setlocal
pushd "%~dp0"
if "%~1"=="" (
    java -jar "Corrigir-Djinns.jar"
) else (
    java -jar "Corrigir-Djinns.jar" "%~f1"
)
echo.
pause
popd

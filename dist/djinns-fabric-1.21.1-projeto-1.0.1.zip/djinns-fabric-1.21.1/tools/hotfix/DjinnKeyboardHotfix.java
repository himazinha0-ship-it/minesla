import java.awt.GraphicsEnvironment;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

/** Repair only the missing production mixin refmap, preserving all original classes. */
public final class DjinnKeyboardHotfix {
    private static final String CONFIG = "djinns.client.mixins.json";
    private static final String MIXIN = "dev/minesla/djinn/mixin/KeyboardInputMixin";
    private static final String REFMAP = "djinns-keyboard-hotfix.refmap.json";
    private static final String SELECTORS = """
        {"tick":"Lnet/minecraft/class_743;method_3129(ZF)V",
         "tick(ZF)V":"Lnet/minecraft/class_743;method_3129(ZF)V"}
        """.trim();

    static byte[] refmap() {
        String mappings = "{\"" + MIXIN + "\":" + SELECTORS + "}";
        return ("{\"mappings\":" + mappings + ",\"data\":{\"named:intermediary\":" + mappings + "}}").getBytes(StandardCharsets.UTF_8);
    }

    private static byte[] read(ZipFile zip, String name) throws IOException {
        ZipEntry entry = zip.getEntry(name);
        if (entry == null) throw new IOException("Arquivo ausente no mod: " + name);
        try (InputStream in = zip.getInputStream(entry)) { return in.readAllBytes(); }
    }

    public static void repair(Path input, Path output) throws IOException {
        input = input.toAbsolutePath().normalize();
        output = output.toAbsolutePath().normalize();
        if (input.equals(output) || Files.exists(output) && Files.isSameFile(input, output)) {
            throw new IOException("Escolha outro nome para preservar o JAR original.");
        }
        if (Files.exists(output)) throw new IOException("O destino ja existe: " + output);
        boolean created = false, success = false;
        try (ZipFile original = new ZipFile(input.toFile())) {
            String metadata = new String(read(original, "fabric.mod.json"), StandardCharsets.UTF_8);
            if (!Pattern.compile("\"id\"\\s*:\\s*\"djinns\"").matcher(metadata).find()) {
                throw new IOException("Este arquivo nao e o mod Djinns. Selecione o JAR de Djinns instalado.");
            }
            String config = new String(read(original, CONFIG), StandardCharsets.UTF_8).strip();
            if (!config.startsWith("{") || !config.endsWith("}") || !config.contains("KeyboardInputMixin")) {
                throw new IOException("Configuracao de mixin diferente da versao afetada; envie o JAR para analise.");
            }
            if (Pattern.compile("\"refmap\"\\s*:").matcher(config).find()) {
                throw new IOException("Este JAR ja declara um refmap; nao e a versao sem refmap dos relatorios.");
            }
            byte[] mixinClass = read(original, MIXIN + ".class");
            String constants = new String(mixinClass, StandardCharsets.ISO_8859_1);
            if (!constants.contains("net/minecraft/class_743") || !constants.contains("tick")) {
                throw new IOException("Mixin diferente do JAR de producao afetado; envie o JAR para analise.");
            }
            Enumeration<? extends ZipEntry> check = original.entries();
            Set<String> names = new HashSet<>();
            while (check.hasMoreElements()) {
                String name = check.nextElement().getName();
                if (!names.add(name)) throw new IOException("JAR com entradas duplicadas: " + name);
                if (name.toUpperCase(Locale.ROOT).matches("META-INF/[^/]+\\.(SF|RSA|DSA|EC)")) {
                    throw new IOException("JAR assinado: a assinatura deve ser preservada; use uma compilacao oficial corrigida.");
                }
            }
            if (names.contains(REFMAP)) throw new IOException("O JAR ja contem o hotfix.");
            byte[] patchedConfig = ("{\n  \"refmap\": \"" + REFMAP + "\",\n" + config.substring(1)).getBytes(StandardCharsets.UTF_8);
            try (OutputStream file = Files.newOutputStream(output, StandardOpenOption.CREATE_NEW)) {
                created = true;
                try (ZipOutputStream patched = new ZipOutputStream(file)) {
                    Enumeration<? extends ZipEntry> entries = original.entries();
                    while (entries.hasMoreElements()) {
                        ZipEntry entry = entries.nextElement();
                        ZipEntry copy = new ZipEntry(entry.getName());
                        if (entry.getTime() >= 0) copy.setTime(entry.getTime());
                        patched.putNextEntry(copy);
                        if (entry.getName().equals(CONFIG)) patched.write(patchedConfig);
                        else try (InputStream in = original.getInputStream(entry)) { in.transferTo(patched); }
                        patched.closeEntry();
                    }
                    patched.putNextEntry(new ZipEntry(REFMAP));
                    patched.write(refmap());
                    patched.closeEntry();
                }
            }
            try (ZipFile verified = new ZipFile(output.toFile())) {
                if (!Arrays.equals(read(verified, MIXIN + ".class"), mixinClass)) {
                    throw new IOException("Falha na verificacao: a classe original foi modificada.");
                }
                if (!Arrays.equals(read(verified, REFMAP), refmap())) throw new IOException("Falha na verificacao do refmap.");
            }
            success = true;
        } finally {
            if (created && !success) Files.deleteIfExists(output);
        }
    }

    public static void main(String[] args) {
        boolean graphical = args.length == 0 && !GraphicsEnvironment.isHeadless();
        try {
            Path input;
            if (graphical) {
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Selecione o JAR de Djinns que apresenta o erro");
                chooser.setFileFilter(new FileNameExtensionFilter("Mod Djinns (*.jar)", "jar"));
                if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) return;
                input = chooser.getSelectedFile().toPath();
            } else {
                if (args.length < 1 || args.length > 2) throw new IOException("Uso: java -jar Corrigir-Djinns.jar mod.jar [saida.jar]");
                input = Path.of(args[0]);
            }
            String name = input.getFileName().toString().replaceFirst("(?i)\\.jar$", "") + "-corrigido.jar";
            Path output = args.length == 2 ? Path.of(args[1]) : Path.of(name).toAbsolutePath();
            repair(input, output);
            String message = "Correcao criada: " + output.toAbsolutePath() + "\n\n"
                    + "O original foi preservado. Feche o jogo, mova o mod antigo para fora de mods\n"
                    + "e coloque somente o JAR corrigido em mods. Nao coloque este corretor em mods.\n\n"
                    + "O hotfix adiciona o refmap ausente; o teste dentro do Minecraft ainda e necessario.";
            System.out.println(message);
            if (graphical) JOptionPane.showMessageDialog(null, message, "Djinns - hotfix", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception error) {
            System.err.println("Nao foi possivel corrigir: " + error.getMessage());
            if (graphical) JOptionPane.showMessageDialog(null, error.getMessage(), "Djinns - erro", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }
}

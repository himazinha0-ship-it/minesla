"""Integration tests for archive repair; these do not launch Minecraft."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[2]
MIXIN = 'dev/minesla/djinn/mixin/KeyboardInputMixin'
CONFIG = 'djinns.client.mixins.json'
REFMAP = 'djinns-keyboard-hotfix.refmap.json'
JDK = Path(os.environ.get('JAVA_HOME', '/workspace/tools/jdk-21.0.9+10'))

class HotfixTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.workspace = tempfile.TemporaryDirectory(prefix='djinn-hotfix-test-')
        cls.base = Path(cls.workspace.name)
        cls.classes = cls.base / 'classes'
        cls.classes.mkdir()
        subprocess.run([str(JDK / 'bin/javac'), '--release', '21', '-encoding', 'UTF-8',
                        '-d', str(cls.classes), str(ROOT / 'tools/hotfix/DjinnKeyboardHotfix.java')], check=True)
        # A real compiled binary fixture tests that archive repair never changes code.
        fixture = cls.base / 'KeyboardInputMixin.java'
        fixture.write_text('package dev.minesla.djinn.mixin; public class KeyboardInputMixin {'
                           ' public static final String TARGET = "net/minecraft/class_743";'
                           ' public void tick(boolean slowDown, float factor) {} }')
        subprocess.run([str(JDK / 'bin/javac'), '--release', '21', '-d', str(cls.classes), str(fixture)], check=True)
        cls.mixin_bytes = (cls.classes / (MIXIN + '.class')).read_bytes()

    @classmethod
    def tearDownClass(cls):
        cls.workspace.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=self.base)
        self.work = Path(self.temp.name)
        self.source, self.output = self.work / 'mod.jar', self.work / 'mod-corrigido.jar'

    def tearDown(self): self.temp.cleanup()

    def fixture(self, mod_id='djinns', config=None, signed=False, mixin=True):
        with zipfile.ZipFile(self.source, 'w') as z:
            z.writestr('fabric.mod.json', json.dumps({'id': mod_id, 'version': '1.0.0'}))
            z.writestr(CONFIG, json.dumps(config or {'required': True, 'package': 'dev.minesla.djinn.mixin',
                                                      'client': ['KeyboardInputMixin']}))
            if mixin: z.writestr(MIXIN + '.class', self.mixin_bytes)
            z.writestr('assets/djinns/test.bin', bytes(range(256)))
            if signed: z.writestr('META-INF/MOD.SF', 'test-signature-preservation')

    def run_tool(self, source=None, output=None):
        return subprocess.run([str(JDK / 'bin/java'), '-cp', str(self.classes), 'DjinnKeyboardHotfix',
                               str(source or self.source), str(output or self.output)], capture_output=True)

    def test_success_preserves_original_and_every_class_and_asset(self):
        self.fixture()
        before = self.source.read_bytes()
        result = self.run_tool()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.source.read_bytes(), before)
        with zipfile.ZipFile(self.source) as original, zipfile.ZipFile(self.output) as patched:
            self.assertIsNone(patched.testzip())
            self.assertEqual(set(patched.namelist()), set(original.namelist()) | {REFMAP})
            for name in original.namelist():
                if name != CONFIG: self.assertEqual(patched.read(name), original.read(name), name)
            cfg = json.loads(patched.read(CONFIG))
            self.assertEqual(cfg['refmap'], REFMAP)
            mapping = json.loads(patched.read(REFMAP))
            for selector in ['tick', 'tick(ZF)V']:
                self.assertEqual(mapping['mappings'][MIXIN][selector], 'Lnet/minecraft/class_743;method_3129(ZF)V')
            self.assertEqual(mapping['data']['named:intermediary'], mapping['mappings'])

    def test_already_fixed_is_rejected(self):
        self.fixture()
        self.assertEqual(self.run_tool().returncode, 0)
        next_output = self.work / 'double-patch.jar'
        result = self.run_tool(self.output, next_output)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(next_output.exists())

    def test_unrelated_mod_is_rejected(self):
        self.fixture(mod_id='other_mod')
        self.assertNotEqual(self.run_tool().returncode, 0)
        self.assertFalse(self.output.exists())

    def test_signed_jar_is_rejected_without_changing_signature(self):
        self.fixture(signed=True)
        digest = hashlib.sha256(self.source.read_bytes()).digest()
        self.assertNotEqual(self.run_tool().returncode, 0)
        self.assertFalse(self.output.exists())
        self.assertEqual(hashlib.sha256(self.source.read_bytes()).digest(), digest)

    def test_existing_output_is_never_overwritten(self):
        self.fixture()
        self.output.write_bytes(b'pre-existing user file')
        self.assertNotEqual(self.run_tool().returncode, 0)
        self.assertEqual(self.output.read_bytes(), b'pre-existing user file')

    def test_cannot_overwrite_input(self):
        self.fixture()
        before = self.source.read_bytes()
        self.assertNotEqual(self.run_tool(output=self.source).returncode, 0)
        self.assertEqual(self.source.read_bytes(), before)

    def test_missing_mixin_fails_without_output(self):
        self.fixture(mixin=False)
        self.assertNotEqual(self.run_tool().returncode, 0)
        self.assertFalse(self.output.exists())

if __name__ == '__main__': unittest.main(verbosity=2)
